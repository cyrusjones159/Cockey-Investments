﻿using System;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using statsback542.Models;

namespace somecontrollers.Controllers;

public static class AllstockEndpoints
{
    public static void MapAllstockEndpoints(this IEndpointRouteBuilder routes)
    {
        var group = routes.MapGroup("/api/Allstock").WithTags(nameof(Allstock));

        // GET all
        group.MapGet("/", () =>
        {
            using (var context = new SubmissionStats542Context())
            {
                return context.Allstocks.ToList();
            }
        })
        .WithName("GetAllAllstocks")
        .WithOpenApi();

        // GET by ID
        group.MapGet("/{Id}", (int Id) =>
        {
            using (var context = new SubmissionStats542Context())
            {
                return context.Allstocks.Where(m => m.Id == Id).ToList();
            }
        })
        .WithName("GetAllstockById")
        .WithOpenApi();

    group.MapPut("/{id}", 
        async Task<IResult> (int Id, Allstock input) =>
        {
            using (var context = new SubmissionStats542Context())
            {
                var stock = context.Allstocks.FirstOrDefault(m => m.Id == Id);
                if (stock == null)
                    return TypedResults.NotFound();

                context.Allstocks.Attach(stock);

                stock.Company = input.Company;
                await context.SaveChangesAsync();
                return TypedResults.Accepted("Updated ID:" + input.Id);
            }
        })
        .WithName("UpdateAllstock")
        .WithOpenApi();

        // POST create
        group.MapPost("/", async Task<IResult> (Allstock input) =>
        {
            using (var context = new SubmissionStats542Context())
            {
                context.Allstocks.Add(input);
                await context.SaveChangesAsync();
                return TypedResults.Created("Created ID:" + input.Id);
            }
        })
        .WithName("CreateAllstock")
        .WithOpenApi();

        // DELETE
        group.MapDelete("/{Id}", async Task<IResult> (int Id) =>
        {
            using (var context = new SubmissionStats542Context())
            {
                var stock = context.Allstocks.FirstOrDefault(m => m.Id == Id);
                if (stock == null)
                    return TypedResults.NotFound();

                context.Allstocks.Remove(stock);
                await context.SaveChangesAsync();
                return TypedResults.Ok();
            }
        })
        .WithName("DeleteAllstock")
        .WithOpenApi();
    }
}
