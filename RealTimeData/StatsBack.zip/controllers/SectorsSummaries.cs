using System;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using statsback542.Models;

namespace somecontrollers.Controllers;

public static class SectorsummaryEndpoints
{
    public static void MapSectorsummaryEndpoints(this IEndpointRouteBuilder routes)
    {
        var group = routes.MapGroup("/api/Sectorsummaries").WithTags(nameof(Sectorsummary));

        // GET all
        group.MapGet("/", () =>
        {
            using (var context = new SubmissionStats542Context())
            {
                return context.Sectorsummaries.ToList();
            }
        })
        .WithName("GetAllSectorsummaries")
        .WithOpenApi();

        // GET by ID
        group.MapGet("/{Id}", (int Id) =>
        {
            using (var context = new SubmissionStats542Context())
            {
                return context.Sectorsummaries.Where(m => m.Id == Id).ToList();
            }
        })
        .WithName("GetSectorsummaryById")
        .WithOpenApi();

group.MapPut("/{Id}",
    async Task<IResult> (int Id, Sectorsummary input) =>
{
    using (var context = new SubmissionStats542Context())
    {
        var summary = context.Sectorsummaries.FirstOrDefault(m => m.Id == Id);
        if (summary == null)
            return TypedResults.NotFound();

        context.Sectorsummaries.Attach(summary);

        // Only update fields that are NOT null
        void UpdateIfNotNull<T>(Action<T> setter, T value)
        {
            if (value != null)
                setter(value);
        }

        // STRING FIELDS
        UpdateIfNotNull<string>(v => summary.Company = v, input.Company);
        UpdateIfNotNull<string>(v => summary.Ticker = v, input.Ticker);
        UpdateIfNotNull<string>(v => summary.Sector = v, input.Sector);
        UpdateIfNotNull<string>(v => summary.Selected = v, input.Selected);

        // DOUBLE? FIELDS (MATCH YOUR MODEL)
        UpdateIfNotNull<double?>(v => summary.Avgdividend = v, input.Avgdividend);
        UpdateIfNotNull<double?>(v => summary.Totaldividends = v, input.Totaldividends);
        UpdateIfNotNull<double?>(v => summary.PriceStart = v, input.PriceStart);
        UpdateIfNotNull<double?>(v => summary.PriceEnd = v, input.PriceEnd);
        UpdateIfNotNull<double?>(v => summary.Change = v, input.Change);
        UpdateIfNotNull<double?>(v => summary.Totalreturn = v, input.Totalreturn);
        UpdateIfNotNull<double?>(v => summary.Totalreturnover10 = v, input.Totalreturnover10);
        UpdateIfNotNull<double?>(v => summary.Shares500 = v, input.Shares500);
        UpdateIfNotNull<double?>(v => summary.Totalspend = v, input.Totalspend);
        UpdateIfNotNull<double?>(v => summary.Fiveyearequityproj = v, input.Fiveyearequityproj);
        UpdateIfNotNull<double?>(v => summary.Fiveyeardivproj = v, input.Fiveyeardivproj);
        UpdateIfNotNull<double?>(v => summary.Totalfiveyearview = v, input.Totalfiveyearview);

        await context.SaveChangesAsync();
        return TypedResults.Accepted($"Updated ID: {Id}");
    }
})
.WithName("UpdateSectorsummary")
.WithOpenApi();



        // POST create
        group.MapPost("/", async Task<IResult> (Sectorsummary input) =>
        {
            using (var context = new SubmissionStats542Context())
            {
                context.Sectorsummaries.Add(input);
                await context.SaveChangesAsync();
                return TypedResults.Created("Created ID:" + input.Id);
            }
        })
        .WithName("CreateSectorsummary")
        .WithOpenApi();

        // DELETE
        group.MapDelete("/{Id}", async Task<IResult> (int Id) =>
        {
            using (var context = new SubmissionStats542Context())
            {
                var summary = context.Sectorsummaries.FirstOrDefault(m => m.Id == Id);
                if (summary == null)
                    return TypedResults.NotFound();

                context.Sectorsummaries.Remove(summary);
                await context.SaveChangesAsync();
                return TypedResults.Ok();
            }
        })
        .WithName("DeleteSectorsummary")
        .WithOpenApi();
    }
}
