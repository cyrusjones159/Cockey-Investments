﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace statsback542.Models;

public partial class SubmissionStats542Context : DbContext
{
    public SubmissionStats542Context()
    {
    }

    public SubmissionStats542Context(DbContextOptions<SubmissionStats542Context> options)
        : base(options)
    {
    }

    public virtual DbSet<Allstock> Allstocks { get; set; }
    public virtual DbSet<Sectorsummary> Sectorsummaries { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        => optionsBuilder.UseSqlite("Data Source=./data/submission.stats542.sqlite");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // -----------------------------
        // allstocks table
        // -----------------------------
        modelBuilder.Entity<Allstock>(entity =>
        {
            entity.ToTable("allstocks");

            entity.HasKey(e => e.Id);

            entity.Property(e => e.Id).HasColumnName("Id");
            entity.Property(e => e.Company).HasColumnName("Company");
            entity.Property(e => e.Ticker).HasColumnName("Ticker");

            entity.Property(e => e.Price2016).HasColumnName("Price_2016");
            entity.Property(e => e.Price2017).HasColumnName("Price_2017");
            entity.Property(e => e.Price2018).HasColumnName("Price_2018");
            entity.Property(e => e.Price2019).HasColumnName("Price_2019");
            entity.Property(e => e.Price2020).HasColumnName("Price_2020");
            entity.Property(e => e.Price2021).HasColumnName("Price_2021");
            entity.Property(e => e.Price2022).HasColumnName("Price_2022");
            entity.Property(e => e.Price2023).HasColumnName("Price_2023");
            entity.Property(e => e.Price2024).HasColumnName("Price_2024");
            entity.Property(e => e.Price2025).HasColumnName("Price_2025");
            entity.Property(e => e.Price2026).HasColumnName("Price_2026");

            entity.Property(e => e.Div2016).HasColumnName("Div_2016");
            entity.Property(e => e.Div2017).HasColumnName("Div_2017");
            entity.Property(e => e.Div2018).HasColumnName("Div_2018");
            entity.Property(e => e.Div2019).HasColumnName("Div_2019");
            entity.Property(e => e.Div2020).HasColumnName("Div_2020");
            entity.Property(e => e.Div2021).HasColumnName("Div_2021");
            entity.Property(e => e.Div2022).HasColumnName("Div_2022");
            entity.Property(e => e.Div2023).HasColumnName("Div_2023");
            entity.Property(e => e.Div2024).HasColumnName("Div_2024");
            entity.Property(e => e.Div2025).HasColumnName("Div_2025");
            entity.Property(e => e.Div2026).HasColumnName("Div_2026");

            entity.Property(e => e.Sector).HasColumnName("sector");
            entity.Property(e => e.Avgdividend).HasColumnName("avgdividend");
            entity.Property(e => e.Totaldividends).HasColumnName("totaldividends");

            entity.Property(e => e.PriceStart).HasColumnName("price_start");
            entity.Property(e => e.PriceEnd).HasColumnName("price_end");
            entity.Property(e => e.Change).HasColumnName("change");
            entity.Property(e => e.Totalreturn).HasColumnName("totalreturn");
            entity.Property(e => e.Totalreturnover10).HasColumnName("totalreturnover10");

            entity.Property(e => e.Shares500).HasColumnName("shares500");
            entity.Property(e => e.Totalspend).HasColumnName("totalspend");

            entity.Property(e => e.Fiveyearequityproj).HasColumnName("fiveyearequityproj");
            entity.Property(e => e.Fiveyeardivproj).HasColumnName("fiveyeardivproj");
            entity.Property(e => e.Totalfiveyearview).HasColumnName("totalfiveyearview");
        });

        // -----------------------------
        // sectorssummaries table
        // -----------------------------
        modelBuilder.Entity<Sectorsummary>(entity =>
        {
            entity.ToTable("sectorssummaries");

            entity.HasKey(e => e.Id);

            entity.Property(e => e.Id).HasColumnName("Id");
            entity.Property(e => e.Company).HasColumnName("Company");
            entity.Property(e => e.Ticker).HasColumnName("Ticker");
            entity.Property(e => e.Sector).HasColumnName("sector");

            entity.Property(e => e.Avgdividend).HasColumnName("avgdividend");
            entity.Property(e => e.Totaldividends).HasColumnName("totaldividends");

            entity.Property(e => e.PriceStart).HasColumnName("price_start");
            entity.Property(e => e.PriceEnd).HasColumnName("price_end");
            entity.Property(e => e.Change).HasColumnName("change");
            entity.Property(e => e.Totalreturn).HasColumnName("totalreturn");
            entity.Property(e => e.Totalreturnover10).HasColumnName("totalreturnover10");

            entity.Property(e => e.Shares500).HasColumnName("shares500");
            entity.Property(e => e.Totalspend).HasColumnName("totalspend");

            entity.Property(e => e.Fiveyearequityproj).HasColumnName("fiveyearequityproj");
            entity.Property(e => e.Fiveyeardivproj).HasColumnName("fiveyeardivproj");
            entity.Property(e => e.Totalfiveyearview).HasColumnName("totalfiveyearview");

            entity.Property(e => e.Selected).HasColumnName("selected");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}

